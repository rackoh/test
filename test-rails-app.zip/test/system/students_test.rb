require "application_system_test_case"

class StudentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit students_url
  #
  #   assert_selector "h1", text: "Student"
  # end
end
