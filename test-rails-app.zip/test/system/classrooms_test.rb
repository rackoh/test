require "application_system_test_case"

class ClassroomsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit classrooms_url
  #
  #   assert_selector "h1", text: "Classroom"
  # end
end
